$(document).ready(function(){
	$.ajax({
		type: "POST",
		
		crossDomain: true,
		headers: { 'Access-Control-Allow-Origin': '*' },
		url: "https://www.sempreodonto.com.br/mobile/caedu/services/franquias.asp",
		success: function(data)
		{
			$("#result").html(data);
		}
	});
});