﻿$(document).ready(function(){
	$(".button-collapse").sideNav();
	$("select").material_select();
	
	var matricula = getCookie("matricula");
	
	if (matricula == ""){
		matricula = localStorage.getItem('matricula');
	};
	
	$.ajax({
		type: "POST",
		data: "matricula="+matricula,
		crossDomain: true,
		headers: { 'Access-Control-Allow-Origin': '*' },
		url: "https://www.sempreodonto.com.br/mobile/db/services/valida_usuario.asp",
		success: function(data)
		{
			var myArray = data.split("|");
			$("#vNomePlano").html(myArray[3]);
			$("#vANS").html(myArray[4]);
			$("#vDescricao").html(myArray[5]);
		}
	});
	$.ajax({
		type: "POST",
		crossDomain: true,
		headers: { 'Access-Control-Allow-Origin': '*' },			
		url: "https://www.sempreodonto.com.br/mobile/db/services/verifica_especialidades.asp",
		success: function(data){
			$("#especialidade").html(data);
		}
	});
	$("#UF").change(function(){
		
		$("#ld").css("display","block");
		var UF = $("#UF").val();
		$.ajax({
			type: "GET",
			data: "UF="+UF,
			crossDomain: true,
			headers: {'Access-Control-Allow-Origin': '*'},			
			url: "https://www.sempreodonto.com.br/mobile/db/services/verifica_cidade.asp",
			success: function(data){
				$("#cidade").html(data);
				$("#cidade").material_select();
				$("#ld").css("display","none");
				$("#ld").css("display","none");
			}
		});
	});
	$("#cidade").change(function(){
		$("#ld").css("display","block");
		var cidade = $("#cidade").val();
		var teste = "";
		var letra = "";
		var quantidade = cidade.length;
		for (i = 0; i < quantidade; i++) {
			letra = cidade.substr(i, 1); 
			letra = letra.charCodeAt();
			teste = teste + " " + letra.toString(); 
		};
		
		$.ajax({
			type: "GET",
			data: "CIDADE="+teste,
			crossDomain: true,
			headers: { 'Access-Control-Allow-Origin': '*' },			
			url: "https://www.sempreodonto.com.br/mobile/db/services/verifica_bairros.asp",
			success: function(data){
				$("#bairro").html(data);
				$("#bairro").material_select();
				$("#ld").css("display","none");
			}
		});
	});
	$("#consultar_rede").click(function(){
		$("#ld").css("display","block");
		var estabelecimento = $("#estabelecimento").val();
		var especialidade = "";
		var teste = "";
		var bairro = "";
		var UF = $("#UF").val();
		var cidade = $("#cidade").val();
		var bairro = $("#bairro").val();
		
		if (bairro == null){
			bairro = "";
		}
		
		var SelNumSegur = getCookie("matricula");
		if (SelNumSegur == ""){
			SelNumSegur = localStorage.getItem('matricula');
		};
		
		var quantidade = cidade.length;
		for (i = 0; i < quantidade; i++) {
			letra = cidade.substr(i, 1); 
			letra = letra.charCodeAt();
			teste = teste + " " + letra.toString(); 
		};
		
		cidade = teste;
		var teste = "";
		if (bairro != ""){
			var quantidade = bairro.length;
			for (i = 0; i < quantidade; i++) {
				letra = bairro.substr(i, 1); 
				letra = letra.charCodeAt();
				teste = teste + " " + letra.toString(); 
			};
		
			bairro = teste;
		}
		
		$.ajax({
			type: "GET",
			data: "estabelecimento="+estabelecimento+"&especialidade="+especialidade+"&UF="+UF+"&Cidade="+cidade+"&Bairro="+bairro+"&SelNumSegur="+SelNumSegur,
			crossDomain: true,
			headers: { 'Access-Control-Allow-Origin': '*' },
			url: "https://www.sempreodonto.com.br/mobile/db/services/rede_resultado.asp",
			success: function(data)
			{
				$("#ld").css("display","none");
				$("#rede_resultado").html(data);
				$(location).attr("href", "#page2");
			}
		});		
	});
	$("#recarregar").click(function(){
		$(location).attr("href", "rede_credenciada.html");
	});
});