function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length,c.length);
        }
    }
    return "";
}

function capturar(cod_dentista){
	var cvalue = document.getElementById(cod_dentista).value;
	var historico_dentistas = getCookie("historico_dentistas");
	if(historico_dentistas == ""){
		var historico_dentistas = localStorage.getItem("historico_dentistas");
	};
	
	if(historico_dentistas == ""){
		setCookie("historico_dentistas",cod_dentista,10);
		localStorage.setItem("historico_dentistas", cod_dentista);
	}
	else{
		setCookie("historico_dentistas",historico_dentistas + '|' + cod_dentista,10);
		localStorage.setItem("historico_dentistas", historico_dentistas + '|' + cod_dentista);
	}

	var d = new Date();
    d.setTime(d.getTime() + (10*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cod_dentista + "=" + cvalue + "; " + expires;
	localStorage.setItem(cod_dentista, cvalue);
	
	alert("Dentista salvo no seu hist\u00f3rico!");
	//alert(localStorage.getItem(cod_dentista));
}

function remover_historico(cod_dentista){
	var historico_dentistas = getCookie("historico_dentistas");
	
	if (historico_dentistas == ""){
		historico_dentistas = localStorage.getItem('historico_dentistas');
	};
	
	historico_dentistas = historico_dentistas.str.replace(cod_dentista + '|', ""); 
	setCookie("historico_dentistas",historico_dentistas,10);
	localStorage.setItem("historico_dentistas", historico_dentistas);
	alert("Dentista removido do seu hist\u00f3rico com sucesso!");
}


function limpar_historico(){
	setCookie("historico_dentistas","",1)
	localStorage.setItem("historico_dentistas", "");
	alert("Hist\u00f3rico removido com sucesso!");
}

function exibir_historico(){
	var historico_dentistas = getCookie("historico_dentistas");
	//alert(historico_dentistas);
	if (historico_dentistas == ""){
		historico_dentistas = localStorage.getItem('historico_dentistas');
	};
	document.getElementById("historico").innerHTML = "";
	var qtde = historico_dentistas.split("|");
	for (i = 0; i < qtde.length; i++) { 
		dentista = getCookie(qtde[i]);
		if (dentista == ""){
			dentista = localStorage.getItem(qtde[i]);
		};
		//alert(dentista);
		dados = dentista.split("|");
		var a = document.createElement("DIV");
		var titulo = "<h4>"+dados[1]+"</h4>";
		var nome = dados[1];
		var tipo = dados[2];
		var uf = dados[3];
		var cidade = dados[4];
		var bairro = dados[5];
		var logradouro = dados[6];
		var cep = dados[7];
		var telefone = dados[8];
		var oficial = dados[9];
		var nao_oficial = dados[10];
		a.innerHTML = titulo + tipo + "<br>" + uf + "<br>" + cidade + "<br>" + bairro + "<br>" + logradouro + "<br>" + cep + "<br>" + telefone + "<br>" + oficial + "<br>" + nao_oficial + "<br>";
		//a.appendChild(document.createTextNode("<h4>Skúsiť Znova</h4>"));
		a.setAttribute("data-role","collapsible");
		a.setAttribute("data-theme","c");
		a.setAttribute("data-collapsed-icon","arrow-d");
		a.setAttribute("data-expanded-icon","arrow-u");

		$('#historico').append(a).trigger('create');
	};
}